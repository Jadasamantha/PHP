<html>

<head>
  <title> Hello Function </title>
</head>

<body>
  <h1> Hello Function</h1>

  <?php
//define function.

function hello(){
  echo "Hello, World!";
}
//Call function.

hello();
   ?>
 </body>
 </html>
