<!doctype html>
<head>
  <title>Array Assignment 2</title>
</head>

<body>

  <?php

$a= array(0, 1, 2, 3, 4, 5, 6);

echo "sum = " . array_sum($a) . "\n";

?>
</body>
