<!doctype html>
<head>
  <title>Array Assignment</title>
</head>

<body>
  <?php


$a = array (0, 1, 2, 3, 4);

$a[0] ='0';
$a[1] = '1';
$a[2] = '2';
$a[3] = '3';
$a[4] = '4';

echo "Extract the number  $a[3]\n";
echo '<br>';


?>
