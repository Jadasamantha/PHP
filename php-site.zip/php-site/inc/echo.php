<?php

  $numbers = 123;
  echo "why did the lizard go on a diet";
  echo "<br>";
  echo 'It weighted to much for its scale';
  echo $numbers;


  ?>
