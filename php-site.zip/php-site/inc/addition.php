<?php
 $addition = 5 + 5;
 echo $addition;  // Result:10

  $subtraction = 5-5;
  echo  $subtraction; // Result: 0
  echo "\n";
  echo "<br>";

  $multiplication = 5*5;
  echo $multiplication;  // Result: 25
  echo "\n";
  echo "<br>";

 $division = 5 / 5;
  echo $division;  // Result: 1
  echo "\n";
  echo "<br>";

  $modulus = 7 % 5;
  echo $modulus;   // Result: 2
  echo "\n";
  echo "<br>";
  echo 3 + 5 / 2;  // Result: 5.5
  ?>
