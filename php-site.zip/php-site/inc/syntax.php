<?php
   $variable = "why can you never swindle a snake";
   echo $variable;
   ?>
