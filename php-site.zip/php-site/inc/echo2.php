<?php

 echo '<p style="color: green;">YES, a green apple 🍏</p>';
 echo "<p style=\"color: red;\">YES, an 🍎</p>";


 echo "What's this? No error message?";
 echo 'What\'s this? No error message?';

?>
